import { Link } from "wouter";
import { Facebook, Instagram, Twitter } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground pt-16 pb-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h3 className="text-xl font-semibold mb-4">ModernShop</h3>
            <p className="text-secondary-foreground/70 mb-6">
              Enhancing your everyday life with cutting-edge products designed for modern living.
            </p>
            <div className="flex space-x-4">
              <SocialLink href="#" icon={<Facebook className="w-5 h-5" />} />
              <SocialLink href="#" icon={<Instagram className="w-5 h-5" />} />
              <SocialLink href="#" icon={<Twitter className="w-5 h-5" />} />
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Shop</h3>
            <FooterLinkGroup>
              <FooterLink href="/products?category=electronics">Electronics</FooterLink>
              <FooterLink href="/products?category=home">Home & Living</FooterLink>
              <FooterLink href="/products?category=accessories">Accessories</FooterLink>
              <FooterLink href="/products?filter=new">New Arrivals</FooterLink>
              <FooterLink href="/products?filter=sale">Sale</FooterLink>
            </FooterLinkGroup>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
            <FooterLinkGroup>
              <FooterLink href="#">Contact Us</FooterLink>
              <FooterLink href="#">FAQs</FooterLink>
              <FooterLink href="#">Shipping & Returns</FooterLink>
              <FooterLink href="#">Track Order</FooterLink>
              <FooterLink href="#">Support</FooterLink>
            </FooterLinkGroup>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">About</h3>
            <FooterLinkGroup>
              <FooterLink href="#">Our Story</FooterLink>
              <FooterLink href="#">Blog</FooterLink>
              <FooterLink href="#">Press</FooterLink>
              <FooterLink href="#">Careers</FooterLink>
              <FooterLink href="#">Privacy Policy</FooterLink>
            </FooterLinkGroup>
          </div>
        </div>
        
        <div className="border-t border-secondary-foreground/20 pt-8 mt-8 text-center text-secondary-foreground/70 text-sm">
          <p>&copy; {new Date().getFullYear()} ModernShop. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

interface SocialLinkProps {
  href: string;
  icon: React.ReactNode;
}

const SocialLink = ({ href, icon }: SocialLinkProps) => {
  return (
    <a 
      href={href} 
      className="text-secondary-foreground/70 hover:text-secondary-foreground transition-colors"
      target="_blank" 
      rel="noopener noreferrer"
    >
      {icon}
    </a>
  );
};

interface FooterLinkGroupProps {
  children: React.ReactNode;
}

const FooterLinkGroup = ({ children }: FooterLinkGroupProps) => {
  return (
    <ul className="space-y-2 text-secondary-foreground/70">
      {children}
    </ul>
  );
};

interface FooterLinkProps {
  href: string;
  children: React.ReactNode;
}

const FooterLink = ({ href, children }: FooterLinkProps) => {
  return (
    <li>
      <Link href={href} className="hover:text-secondary-foreground transition-colors">
        {children}
      </Link>
    </li>
  );
};

export default Footer;
