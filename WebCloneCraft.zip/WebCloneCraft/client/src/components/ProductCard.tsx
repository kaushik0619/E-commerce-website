import { Link } from "wouter";
import { Product } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShoppingBag, Star } from "lucide-react";
import { useCart } from "./cart/CartProvider";
import { cn, formatCurrency } from "@/lib/utils";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
  delay?: number;
}

const ProductCard = ({ product, delay = 0 }: ProductCardProps) => {
  const { addToCart } = useCart();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product.id);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
      viewport={{ once: true }}
    >
      <Card className="product-card group overflow-hidden h-full hover:shadow-md transition-all duration-300">
        <Link href={`/products/${product.slug}`} className="block">
          <div className="relative overflow-hidden aspect-square">
            <img 
              src={product.imageUrl}
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" 
            />
            {(product.isNew || product.isSale || product.isPopular) && (
              <div className="absolute top-3 right-3">
                {product.isNew && (
                  <Badge className="bg-accent text-accent-foreground">New</Badge>
                )}
                {product.isSale && (
                  <Badge className="bg-success text-white ml-1">Sale</Badge>
                )}
                {product.isPopular && (
                  <Badge className="bg-primary text-primary-foreground ml-1">Popular</Badge>
                )}
              </div>
            )}
          </div>
          <CardContent className="p-4">
            <div className="flex justify-between items-start mb-2">
              <h3 className="text-lg font-semibold truncate">{product.name}</h3>
              <div className="text-right">
                <span className="text-primary font-medium">
                  {formatCurrency(Number(product.price))}
                </span>
                {product.originalPrice && (
                  <span className="text-muted-foreground text-sm line-through ml-1">
                    {formatCurrency(Number(product.originalPrice))}
                  </span>
                )}
              </div>
            </div>
            <p className="text-sm text-muted-foreground mb-3 line-clamp-2">
              {product.description}
            </p>
            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                <span className="text-xs text-muted-foreground ml-1">
                  {product.rating}
                </span>
              </div>
              <Button 
                size="icon" 
                variant="outline" 
                className={cn(
                  "w-9 h-9 rounded-full transition-colors",
                  "hover:bg-primary hover:text-primary-foreground hover:border-primary"
                )}
                onClick={handleAddToCart}
              >
                <ShoppingBag className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Link>
      </Card>
    </motion.div>
  );
};

export default ProductCard;
