import React, { useState, useEffect } from "react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useCart } from "./cart/CartProvider";
import { ArrowRight } from "lucide-react";

const ScrollPopup = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { setIsCartOpen } = useCart();
  
  // Check if we've already shown the popup in this session
  const [hasShownPopup, setHasShownPopup] = useState(() => {
    if (typeof window !== 'undefined') {
      return sessionStorage.getItem('hasShownScrollPopup') === 'true';
    }
    return false;
  });

  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    const handleScroll = () => {
      // Show popup when user scrolls 30% down the page
      const scrollThreshold = document.documentElement.scrollHeight * 0.3;
      const currentScroll = window.scrollY + window.innerHeight;
      
      if (currentScroll > scrollThreshold && !hasShownPopup) {
        if (timeout) clearTimeout(timeout);
        
        // Delay the popup slightly for better UX
        timeout = setTimeout(() => {
          setIsOpen(true);
          setHasShownPopup(true);
          sessionStorage.setItem('hasShownScrollPopup', 'true');
        }, 500);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => {
      window.removeEventListener("scroll", handleScroll);
      if (timeout) clearTimeout(timeout);
    };
  }, [hasShownPopup]);

  const handleViewCart = () => {
    setIsOpen(false);
    setIsCartOpen(true);
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Special Offer!</DialogTitle>
          <DialogDescription>
            Looking for amazing products at unbeatable prices?
          </DialogDescription>
        </DialogHeader>
        
        <div className="py-4">
          <div className="rounded-lg overflow-hidden mb-4">
            <img 
              src="https://images.unsplash.com/photo-1607082350899-7e105aa886ae?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80" 
              alt="Special offer" 
              className="w-full h-48 object-cover"
            />
          </div>
          <p className="text-sm mb-4">
            Get <span className="font-bold">20% off</span> on all electronics when you shop today. 
            Use code <span className="bg-primary/10 text-primary px-2 py-1 rounded font-mono">POPUP20</span> at checkout.
          </p>
        </div>
        
        <DialogFooter className="flex-col sm:flex-row sm:justify-between gap-2">
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Maybe Later
          </Button>
          <Button onClick={handleViewCart} className="gap-2">
            View Products <ArrowRight className="h-4 w-4" />
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ScrollPopup;