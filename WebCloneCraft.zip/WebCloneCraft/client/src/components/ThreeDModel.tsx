import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

interface ThreeDModelProps {
  className?: string;
}

const ThreeDModel = ({ className }: ThreeDModelProps) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);

  useEffect(() => {
    if (!mountRef.current) return;

    const width = mountRef.current.clientWidth;
    const height = mountRef.current.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    
    // Camera setup
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 5;

    // Renderer setup
    const renderer = new THREE.WebGLRenderer({ 
      antialias: true,
      alpha: true 
    });
    renderer.setSize(width, height);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(window.devicePixelRatio);
    mountRef.current.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Controls for interactivity
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping = true;
    controls.dampingFactor = 0.05;
    controls.rotateSpeed = 0.5;
    controls.enableZoom = false;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.5);
    scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x0666EB, 2);
    pointLight.position.set(5, 5, 5);
    scene.add(pointLight);

    const pointLight2 = new THREE.PointLight(0x7A3FFC, 2);
    pointLight2.position.set(-5, -5, 5);
    scene.add(pointLight2);

    // Create a 3D model (a stylized headphone shape)
    const group = new THREE.Group();
    scene.add(group);

    // Create a torus for the headband
    const headbandGeometry = new THREE.TorusGeometry(1.2, 0.1, 16, 50, Math.PI);
    const headbandMaterial = new THREE.MeshStandardMaterial({
      color: 0x111111,
      metalness: 0.8,
      roughness: 0.2,
    });
    const headband = new THREE.Mesh(headbandGeometry, headbandMaterial);
    headband.rotation.x = Math.PI / 2;
    headband.rotation.z = Math.PI;
    group.add(headband);

    // Create ear cups
    const earcupGeometry = new THREE.CylinderGeometry(0.5, 0.5, 0.2, 32);
    const earcupMaterial = new THREE.MeshStandardMaterial({
      color: 0x0666EB,
      metalness: 0.5,
      roughness: 0.3,
    });

    // Left ear cup
    const leftEarcup = new THREE.Mesh(earcupGeometry, earcupMaterial);
    leftEarcup.position.set(-1.2, 0, 0);
    leftEarcup.rotation.x = Math.PI / 2;
    group.add(leftEarcup);

    // Right ear cup
    const rightEarcup = new THREE.Mesh(earcupGeometry, earcupMaterial);
    rightEarcup.position.set(1.2, 0, 0);
    rightEarcup.rotation.x = Math.PI / 2;
    group.add(rightEarcup);

    // Inner ear pads
    const earpadGeometry = new THREE.TorusGeometry(0.35, 0.1, 16, 32);
    const earpadMaterial = new THREE.MeshStandardMaterial({
      color: 0x222222,
      metalness: 0.2,
      roughness: 0.8,
    });

    // Left ear pad
    const leftEarpad = new THREE.Mesh(earpadGeometry, earpadMaterial);
    leftEarpad.position.set(-1.2, 0, 0.1);
    leftEarpad.rotation.x = Math.PI / 2;
    group.add(leftEarpad);

    // Right ear pad
    const rightEarpad = new THREE.Mesh(earpadGeometry, earpadMaterial);
    rightEarpad.position.set(1.2, 0, 0.1);
    rightEarpad.rotation.x = Math.PI / 2;
    group.add(rightEarpad);

    // Initial rotation
    group.rotation.x = -0.2;
    group.rotation.y = -0.5;

    // Animation
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Gently rotate the model
      group.rotation.y += 0.002;
      
      controls.update();
      renderer.render(scene, camera);
    };
    
    animate();

    // Resize handler
    const handleResize = () => {
      if (!mountRef.current || !renderer || !camera) return;
      
      const width = mountRef.current.clientWidth;
      const height = mountRef.current.clientHeight;
      
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      window.removeEventListener('resize', handleResize);
      
      if (mountRef.current && rendererRef.current) {
        mountRef.current.removeChild(rendererRef.current.domElement);
      }
      
      renderer.dispose();
    };
  }, []);

  return (
    <motion.div 
      ref={mountRef}
      className={cn(
        "relative h-80 sm:h-96 md:h-[450px] w-full rounded-xl overflow-hidden",
        "bg-gradient-to-r from-blue-50/20 to-purple-50/20",
        "flex items-center justify-center",
        className
      )}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.6, delay: 0.3 }}
    >
      <div className="absolute bottom-6 left-6 right-6 flex justify-between z-10">
        <span className="text-sm font-medium bg-black/30 text-white backdrop-blur-sm py-1 px-3 rounded-full">
          Experience in 3D
        </span>
        <button className="bg-white text-primary rounded-full w-10 h-10 flex items-center justify-center shadow-lg">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
          </svg>
        </button>
      </div>
    </motion.div>
  );
};

export default ThreeDModel;
