import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useTheme } from "@/components/ui/theme-provider";
import { useCart } from "./cart/CartProvider";
import SearchDialog from "./SearchDialog";
import { cn } from "@/lib/utils";
import { ShoppingBag, Search, User, Sun, Moon, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const { cart, isCartOpen, setIsCartOpen } = useCart();
  const [location] = useLocation();

  const totalItems = cart.reduce((total, item) => total + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      setIsScrolled(scrollPosition > 10);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const closeMobileMenu = () => {
    setIsMobileMenuOpen(false);
  };

  const toggleSearch = () => {
    setIsSearchOpen(!isSearchOpen);
  };

  const toggleTheme = () => {
    setTheme(theme === "light" ? "dark" : "light");
  };

  const toggleCart = () => {
    setIsCartOpen(!isCartOpen);
  };

  return (
    <header 
      className={cn(
        "fixed top-0 left-0 w-full bg-background/90 backdrop-blur-sm z-50 border-b transition-all duration-200",
        isScrolled ? "shadow-sm" : ""
      )}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <Link href="/" className="text-primary font-bold text-2xl">
              ModernShop
            </Link>
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <NavLink href="/" label="Home" current={location === "/"} onClick={closeMobileMenu} />
            <NavLink href="/products" label="Products" current={location === "/products" || location.startsWith("/products/")} onClick={closeMobileMenu} />
            <NavLink href="/products?category=electronics" label="Electronics" current={location === "/products?category=electronics"} onClick={closeMobileMenu} />
            <NavLink href="/products?category=lifestyle" label="Lifestyle" current={location === "/products?category=lifestyle"} onClick={closeMobileMenu} />
          </nav>
          
          {/* Right Menu: Search, Theme, Cart, Account */}
          <div className="flex items-center space-x-2">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleSearch}
              className="rounded-full"
            >
              <Search className="h-5 w-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleTheme}
              className="rounded-full"
            >
              {theme === "light" ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={toggleCart}
              className="rounded-full relative"
            >
              <ShoppingBag className="h-5 w-5" />
              {totalItems > 0 && (
                <span className="absolute -top-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {totalItems}
                </span>
              )}
            </Button>
            <Button 
              variant="ghost" 
              size="icon"
              className="rounded-full"
            >
              <User className="h-5 w-5" />
            </Button>
            
            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={toggleMobileMenu}
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden py-4 space-y-1 border-t">
            <div className="flex flex-col space-y-3 p-2">
              <NavLink href="/" label="Home" current={location === "/"} onClick={closeMobileMenu} />
              <NavLink href="/products" label="Products" current={location === "/products" || location.startsWith("/products/")} onClick={closeMobileMenu} />
              <NavLink href="/products?category=electronics" label="Electronics" current={location === "/products?category=electronics"} onClick={closeMobileMenu} />
              <NavLink href="/products?category=lifestyle" label="Lifestyle" current={location === "/products?category=lifestyle"} onClick={closeMobileMenu} />
            </div>
          </div>
        )}
      </div>

      {/* Search Dialog */}
      <SearchDialog open={isSearchOpen} onOpenChange={setIsSearchOpen} />
    </header>
  );
};

interface NavLinkProps {
  href: string;
  label: string;
  current: boolean;
  onClick?: () => void;
}

const NavLink = ({ href, label, current, onClick }: NavLinkProps) => {
  return (
    <Link 
      href={href} 
      className={cn(
        "px-3 py-2 rounded-md text-base font-medium transition-colors duration-200",
        current 
          ? "text-primary" 
          : "text-foreground/80 hover:text-primary"
      )}
      onClick={onClick}
    >
      {label}
    </Link>
  );
};

export default Header;
