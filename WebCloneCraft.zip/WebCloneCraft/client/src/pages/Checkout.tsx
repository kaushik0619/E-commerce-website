import { useState } from "react";
import { useLocation } from "wouter";
import { useCart } from "@/components/cart/CartProvider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatCurrency } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { 
  CreditCard, 
  ShieldCheck, 
  Clock, 
  Package, 
  ArrowLeft, 
  LucideIcon, 
  CheckCircle2 
} from "lucide-react";

const Checkout = () => {
  const [, navigate] = useLocation();
  const { cart, getCartTotal, clearCart } = useCart();
  const { toast } = useToast();
  const [step, setStep] = useState<string>('details');
  const [isProcessing, setIsProcessing] = useState(false);

  // Form data state
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    zipCode: "",
    country: "",
    cardName: "",
    cardNumber: "",
    expDate: "",
    cvv: "",
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmitDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('payment');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      setIsProcessing(false);
      setStep('confirmation');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      clearCart();
    }, 2000);
  };

  if (cart.length === 0 && step !== 'confirmation') {
    return (
      <div className="pt-24 pb-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-md mx-auto text-center py-12">
            <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
            <p className="text-muted-foreground mb-6">
              Add some products to your cart before proceeding to checkout.
            </p>
            <Button onClick={() => navigate("/products")}>
              Browse Products
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto">
          {/* Back button */}
          {step !== 'confirmation' && (
            <div className="mb-6">
              <Button 
                variant="ghost" 
                className="flex items-center gap-1" 
                onClick={() => navigate("/products")}
              >
                <ArrowLeft className="h-4 w-4" />
                Back
              </Button>
            </div>
          )}

          <h1 className="text-3xl font-bold mb-8 text-center">
            {step === 'confirmation' ? 'Order Confirmation' : 'Checkout'}
          </h1>

          {step !== 'confirmation' && (
            <div className="flex justify-center mb-8">
              <div className="relative flex items-center w-full max-w-lg">
                <CheckoutStep 
                  number={1} 
                  title="Details" 
                  active={step === 'details'} 
                  completed={step === 'payment' || step === 'confirmation'}
                />
                <Separator className="flex-grow mx-2" />
                <CheckoutStep 
                  number={2} 
                  title="Payment" 
                  active={step === 'payment'} 
                  completed={step === 'confirmation'}
                />
                <Separator className="flex-grow mx-2" />
                <CheckoutStep 
                  number={3} 
                  title="Confirmation" 
                  active={step === 'confirmation'} 
                  completed={false}
                />
              </div>
            </div>
          )}

          {step === 'details' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <form onSubmit={handleSubmitDetails}>
                  <Card>
                    <CardContent className="p-6">
                      <h2 className="text-xl font-semibold mb-4">Shipping Details</h2>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor="firstName">First Name</Label>
                          <Input 
                            id="firstName" 
                            name="firstName"
                            value={formData.firstName}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="lastName">Last Name</Label>
                          <Input 
                            id="lastName" 
                            name="lastName"
                            value={formData.lastName}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label htmlFor="email">Email</Label>
                          <Input 
                            id="email" 
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="phone">Phone</Label>
                          <Input 
                            id="phone" 
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                      </div>

                      <div className="space-y-2 mb-4">
                        <Label htmlFor="address">Address</Label>
                        <Textarea 
                          id="address" 
                          name="address"
                          value={formData.address}
                          onChange={handleInputChange}
                          required 
                        />
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div className="space-y-2">
                          <Label htmlFor="city">City</Label>
                          <Input 
                            id="city" 
                            name="city"
                            value={formData.city}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="zipCode">Zip Code</Label>
                          <Input 
                            id="zipCode" 
                            name="zipCode"
                            value={formData.zipCode}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                        <div className="space-y-2">
                          <Label htmlFor="country">Country</Label>
                          <Input 
                            id="country" 
                            name="country"
                            value={formData.country}
                            onChange={handleInputChange}
                            required 
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="mt-6 flex justify-end">
                    <Button type="submit" size="lg">
                      Continue to Payment
                    </Button>
                  </div>
                </form>
              </div>
              
              <OrderSummary cart={cart} getCartTotal={getCartTotal} />
            </div>
          )}

          {step === 'payment' && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <form onSubmit={handleSubmitPayment}>
                  <Card>
                    <CardContent className="p-6">
                      <h2 className="text-xl font-semibold mb-4">Payment Method</h2>
                      
                      <Tabs defaultValue="card" className="mb-6">
                        <TabsList className="grid w-full grid-cols-3">
                          <TabsTrigger value="card">Credit Card</TabsTrigger>
                          <TabsTrigger value="paypal">PayPal</TabsTrigger>
                          <TabsTrigger value="applepay">Apple Pay</TabsTrigger>
                        </TabsList>
                        <TabsContent value="card" className="pt-4">
                          <div className="space-y-4">
                            <div className="space-y-2">
                              <Label htmlFor="cardName">Name on Card</Label>
                              <Input 
                                id="cardName" 
                                name="cardName"
                                value={formData.cardName}
                                onChange={handleInputChange}
                                required 
                              />
                            </div>
                            <div className="space-y-2">
                              <Label htmlFor="cardNumber">Card Number</Label>
                              <Input 
                                id="cardNumber" 
                                name="cardNumber"
                                value={formData.cardNumber}
                                onChange={handleInputChange}
                                placeholder="1234 5678 9012 3456"
                                required 
                              />
                            </div>
                            <div className="grid grid-cols-2 gap-4">
                              <div className="space-y-2">
                                <Label htmlFor="expDate">Expiration Date</Label>
                                <Input 
                                  id="expDate" 
                                  name="expDate"
                                  value={formData.expDate}
                                  onChange={handleInputChange}
                                  placeholder="MM/YY"
                                  required 
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="cvv">CVV</Label>
                                <Input 
                                  id="cvv" 
                                  name="cvv"
                                  value={formData.cvv}
                                  onChange={handleInputChange}
                                  placeholder="123"
                                  required 
                                />
                              </div>
                            </div>
                          </div>
                        </TabsContent>
                        <TabsContent value="paypal" className="pt-4">
                          <div className="text-center py-6">
                            <p className="text-muted-foreground mb-4">
                              You will be redirected to PayPal to complete your purchase.
                            </p>
                            <Button className="w-full">Continue with PayPal</Button>
                          </div>
                        </TabsContent>
                        <TabsContent value="applepay" className="pt-4">
                          <div className="text-center py-6">
                            <p className="text-muted-foreground mb-4">
                              You will be prompted to authenticate with Apple Pay.
                            </p>
                            <Button className="w-full bg-black hover:bg-black/90">
                              Pay with Apple Pay
                            </Button>
                          </div>
                        </TabsContent>
                      </Tabs>

                      <div className="bg-muted/50 p-4 rounded-lg flex items-start gap-3">
                        <ShieldCheck className="h-5 w-5 text-primary mt-0.5" />
                        <p className="text-sm text-muted-foreground">
                          Your payment information is encrypted and secure. We never store your full credit card details.
                        </p>
                      </div>
                    </CardContent>
                  </Card>

                  <div className="mt-6 flex justify-between">
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={() => setStep('details')}
                    >
                      Back to Details
                    </Button>
                    <Button 
                      type="submit" 
                      size="lg"
                      disabled={isProcessing}
                    >
                      {isProcessing ? "Processing..." : "Complete Order"}
                    </Button>
                  </div>
                </form>
              </div>
              
              <OrderSummary cart={cart} getCartTotal={getCartTotal} />
            </div>
          )}

          {step === 'confirmation' && (
            <div className="text-center">
              <div className="mb-6 flex justify-center">
                <div className="rounded-full bg-success/10 p-4">
                  <CheckCircle2 className="h-12 w-12 text-success" />
                </div>
              </div>
              
              <h2 className="text-2xl font-bold mb-2">Thank You for Your Order!</h2>
              <p className="text-muted-foreground mb-6">
                Your order has been placed successfully. We've sent a confirmation email to your inbox.
              </p>
              
              <Card className="mb-8 mx-auto max-w-lg">
                <CardContent className="p-6">
                  <h3 className="font-semibold mb-4">Order Details</h3>
                  
                  <div className="space-y-3">
                    <OrderInfoItem 
                      icon={Package}
                      title="Order Number"
                      description={`#${Math.floor(100000 + Math.random() * 900000)}`}
                    />
                    <OrderInfoItem 
                      icon={Clock}
                      title="Estimated Delivery"
                      description="3-5 business days"
                    />
                  </div>
                </CardContent>
              </Card>
              
              <div className="flex gap-4 justify-center">
                <Button 
                  variant="outline" 
                  onClick={() => navigate("/products")}
                >
                  Continue Shopping
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

interface CheckoutStepProps {
  number: number;
  title: string;
  active: boolean;
  completed: boolean;
}

const CheckoutStep = ({ number, title, active, completed }: CheckoutStepProps) => {
  return (
    <div className="flex flex-col items-center">
      <div 
        className={`w-8 h-8 rounded-full flex items-center justify-center ${
          completed ? 'bg-success text-white' : 
          active ? 'bg-primary text-white' : 
          'bg-muted text-muted-foreground'
        }`}
      >
        {completed ? <CheckCircle2 className="h-4 w-4" /> : number}
      </div>
      <span className={`text-xs mt-1 ${active ? 'font-medium' : ''}`}>{title}</span>
    </div>
  );
};

interface OrderSummaryProps {
  cart: any[];
  getCartTotal: () => number;
}

const OrderSummary = ({ cart, getCartTotal }: OrderSummaryProps) => {
  return (
    <div className="md:col-span-1">
      <Card>
        <CardContent className="p-6">
          <h2 className="text-xl font-semibold mb-4">Order Summary</h2>
          
          <div className="max-h-[300px] overflow-y-auto mb-4">
            {cart.map((item) => (
              <div key={item.id} className="flex gap-3 py-3 border-b">
                <div className="w-16 h-16 rounded-md bg-muted overflow-hidden flex-shrink-0">
                  <img 
                    src={item.product.imageUrl} 
                    alt={item.product.name} 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="flex-grow">
                  <h4 className="font-medium">{item.product.name}</h4>
                  <div className="flex justify-between mt-1">
                    <span className="text-sm text-muted-foreground">
                      {item.quantity} × {formatCurrency(Number(item.product.price))}
                    </span>
                    <span className="font-medium">
                      {formatCurrency(Number(item.product.price) * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="space-y-2 py-2">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>{formatCurrency(getCartTotal())}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Shipping</span>
              <span>Free</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Tax</span>
              <span>{formatCurrency(getCartTotal() * 0.08)}</span>
            </div>
          </div>
          
          <Separator className="my-3" />
          
          <div className="flex justify-between font-semibold">
            <span>Total</span>
            <span>{formatCurrency(getCartTotal() * 1.08)}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

interface OrderInfoItemProps {
  icon: LucideIcon;
  title: string;
  description: string;
}

const OrderInfoItem = ({ icon: Icon, title, description }: OrderInfoItemProps) => {
  return (
    <div className="flex items-start gap-3">
      <div className="p-2 bg-muted rounded-lg">
        <Icon className="h-4 w-4" />
      </div>
      <div className="text-left">
        <p className="text-sm font-medium">{title}</p>
        <p className="text-sm text-muted-foreground">{description}</p>
      </div>
    </div>
  );
};

export default Checkout;
