import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Product, Category } from '@shared/schema';
import ProductCard from '@/components/ProductCard';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { motion } from 'framer-motion';
import { useScrollAnimation } from '@/hooks/use-scroll-animation';

const Products = () => {
  const [location, setLocation] = useLocation();
  const { ref, inView } = useScrollAnimation();
  
  // Parse query parameters
  const urlParams = new URLSearchParams(location.split('?')[1] || '');
  const categoryParam = urlParams.get('category');
  const filterParam = urlParams.get('filter');
  
  const [selectedCategory, setSelectedCategory] = useState<string>(categoryParam || 'all');
  const [selectedFilter, setSelectedFilter] = useState<string>(filterParam || 'all');
  const [sortOrder, setSortOrder] = useState<string>('popular');
  
  // Fetch all products
  const { data: products, isLoading: isLoadingProducts } = useQuery<Product[]>({
    queryKey: ['/api/products'],
  });
  
  // Fetch all categories
  const { data: categories, isLoading: isLoadingCategories } = useQuery<Category[]>({
    queryKey: ['/api/categories'],
  });

  // Update URL when filters change
  useEffect(() => {
    const params = new URLSearchParams();
    if (selectedCategory !== 'all') params.set('category', selectedCategory);
    if (selectedFilter !== 'all') params.set('filter', selectedFilter);
    
    const newLocation = params.toString() ? `/products?${params.toString()}` : '/products';
    setLocation(newLocation);
  }, [selectedCategory, selectedFilter, setLocation]);

  // Filter and sort products
  const filteredProducts = products?.filter(product => {
    // Filter by category
    if (selectedCategory !== 'all') {
      const category = categories?.find(c => c.slug === selectedCategory);
      if (!category || product.categoryId !== category.id) return false;
    }
    
    // Filter by special attributes
    if (selectedFilter === 'new' && !product.isNew) return false;
    if (selectedFilter === 'sale' && !product.isSale) return false;
    if (selectedFilter === 'popular' && !product.isPopular) return false;
    
    return true;
  }) || [];
  
  // Sort products
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    switch (sortOrder) {
      case 'price-low':
        return Number(a.price) - Number(b.price);
      case 'price-high':
        return Number(b.price) - Number(a.price);
      case 'newest':
        return new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime();
      case 'rating':
        return Number(b.rating || 0) - Number(a.rating || 0);
      default: // popular
        return b.isPopular ? 1 : -1;
    }
  });

  const handleCategoryChange = (value: string) => {
    setSelectedCategory(value);
  };

  const handleFilterChange = (value: string) => {
    setSelectedFilter(value);
  };

  const handleSortChange = (value: string) => {
    setSortOrder(value);
  };

  return (
    <div className="pt-24 pb-20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref}>
          <motion.div
            className="text-center mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5 }}
          >
            <h1 className="text-3xl sm:text-4xl font-bold mb-4">Our Collection</h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover our carefully curated selection of premium products designed for modern living.
            </p>
          </motion.div>
          
          {/* Filters */}
          <motion.div 
            className="flex flex-wrap items-center justify-between mb-8 gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            {/* Category Filters */}
            <div className="flex flex-wrap gap-2">
              <FilterButton 
                active={selectedCategory === 'all'} 
                onClick={() => handleCategoryChange('all')}
              >
                All Products
              </FilterButton>
              
              {isLoadingCategories ? (
                Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-9 w-24" />
                ))
              ) : (
                categories?.map((category) => (
                  <FilterButton 
                    key={category.id}
                    active={selectedCategory === category.slug} 
                    onClick={() => handleCategoryChange(category.slug)}
                  >
                    {category.name}
                  </FilterButton>
                ))
              )}
            </div>
            
            {/* Sort Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Sort by:</span>
              <Select
                value={sortOrder}
                onValueChange={handleSortChange}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="popular">Most Popular</SelectItem>
                  <SelectItem value="newest">Newest</SelectItem>
                  <SelectItem value="price-low">Price: Low to High</SelectItem>
                  <SelectItem value="price-high">Price: High to Low</SelectItem>
                  <SelectItem value="rating">Highest Rated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </motion.div>
          
          {/* Special Filters */}
          <motion.div 
            className="flex flex-wrap gap-2 mb-6"
            initial={{ opacity: 0, y: 20 }}
            animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <FilterButton 
              active={selectedFilter === 'all'} 
              onClick={() => handleFilterChange('all')}
            >
              All
            </FilterButton>
            <FilterButton 
              active={selectedFilter === 'new'} 
              onClick={() => handleFilterChange('new')}
            >
              New Arrivals
            </FilterButton>
            <FilterButton 
              active={selectedFilter === 'sale'} 
              onClick={() => handleFilterChange('sale')}
            >
              On Sale
            </FilterButton>
            <FilterButton 
              active={selectedFilter === 'popular'} 
              onClick={() => handleFilterChange('popular')}
            >
              Popular
            </FilterButton>
          </motion.div>
        </div>
        
        {/* Product Grid */}
        {isLoadingProducts ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {Array(8).fill(0).map((_, i) => (
              <Skeleton key={i} className="h-[400px] rounded-xl" />
            ))}
          </div>
        ) : sortedProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {sortedProducts.map((product, index) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                delay={0.1 * (index % 4)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-xl font-medium mb-2">No products found</h3>
            <p className="text-muted-foreground mb-6">
              Try changing your filters to find what you're looking for.
            </p>
            <Button onClick={() => {
              setSelectedCategory('all');
              setSelectedFilter('all');
            }}>
              Reset Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

interface FilterButtonProps {
  children: React.ReactNode;
  active: boolean;
  onClick: () => void;
}

const FilterButton = ({ children, active, onClick }: FilterButtonProps) => {
  return (
    <Button
      variant={active ? "default" : "outline"}
      size="sm"
      onClick={onClick}
      className="px-4 py-2 rounded-lg text-sm font-medium transition-colors"
    >
      {children}
    </Button>
  );
};

export default Products;
