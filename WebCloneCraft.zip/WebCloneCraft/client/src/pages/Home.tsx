import { useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { motion } from "framer-motion";
import { useScrollAnimation } from "@/hooks/use-scroll-animation";
import ThreeDModel from "@/components/ThreeDModel";
import ProductCard from "@/components/ProductCard";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle2, Smartphone, Shield } from "lucide-react";
import { Input } from "@/components/ui/input";

const Home = () => {
  const { ref: heroRef, inView: heroInView } = useScrollAnimation();
  const { ref: featuresRef, inView: featuresInView } = useScrollAnimation();
  const { ref: productsRef, inView: productsInView } = useScrollAnimation();

  const { data: featuredProducts, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });

  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="pt-16">
      {/* Hero Section */}
      <section ref={heroRef} className="relative pt-24 pb-32 overflow-hidden">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center">
            <motion.div 
              className="md:w-1/2 mb-12 md:mb-0"
              initial="hidden"
              animate={heroInView ? "visible" : "hidden"}
              variants={fadeIn}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight mb-6">
                Experience the future of shopping
              </h1>
              <p className="text-lg text-muted-foreground mb-8">
                Discover our unique collection of premium products designed for modern life.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg">
                  <Link href="/products">
                    Browse Products
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
                <Button variant="outline" size="lg">
                  <Link href="#features">Learn More</Link>
                </Button>
              </div>
            </motion.div>
            
            <div className="md:w-1/2">
              <ThreeDModel />
            </div>
          </div>
        </div>
        
        {/* Background elements */}
        <div className="absolute top-20 right-10 w-64 h-64 bg-primary rounded-full opacity-5 blur-3xl"></div>
        <div className="absolute bottom-20 left-10 w-72 h-72 bg-accent rounded-full opacity-5 blur-3xl"></div>
      </section>

      {/* Features Section */}
      <section id="features" ref={featuresRef} className="py-20 bg-gradient-to-b from-background to-background/60">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial="hidden"
            animate={featuresInView ? "visible" : "hidden"}
            variants={fadeIn}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Innovative Features</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our products combine cutting-edge technology with elegant design to enhance your everyday experience.
            </p>
          </motion.div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Smartphone className="h-6 w-6 text-primary" />}
              title="Smart Integration"
              description="Seamlessly connects with your existing smart home ecosystem for a unified experience."
              delay={0.1}
              inView={featuresInView}
            />
            
            <FeatureCard 
              icon={<CheckCircle2 className="h-6 w-6 text-primary" />}
              title="Intuitive Controls"
              description="Simple, user-friendly interface that makes complex technology accessible to everyone."
              delay={0.2}
              inView={featuresInView}
            />
            
            <FeatureCard 
              icon={<Shield className="h-6 w-6 text-primary" />}
              title="Enhanced Security"
              description="Advanced protection features keep your data and privacy secure at all times."
              delay={0.3}
              inView={featuresInView}
            />
          </div>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" ref={productsRef} className="py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div 
            className="text-center mb-16"
            initial="hidden"
            animate={productsInView ? "visible" : "hidden"}
            variants={fadeIn}
            transition={{ duration: 0.5 }}
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Featured Products</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Discover our carefully curated selection of premium products designed for modern living.
            </p>
          </motion.div>
          
          {isLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="h-[400px] rounded-xl bg-muted animate-pulse" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredProducts?.slice(0, 3).map((product, index) => (
                <ProductCard 
                  key={product.id} 
                  product={product} 
                  delay={0.1 * index}
                />
              ))}
            </div>
          )}
          
          <div className="mt-12 text-center">
            <Button variant="outline" asChild>
              <Link href="/products">View All Products</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Newsletter Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-primary to-accent rounded-2xl p-8 md:p-12 lg:p-16 text-white relative overflow-hidden">
            {/* Background elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white rounded-full opacity-10 -mr-20 -mt-20"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-white rounded-full opacity-10 -ml-20 -mb-20"></div>
            
            <div className="relative z-10 max-w-3xl">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">Stay ahead with exclusive offers</h2>
              <p className="opacity-90 mb-8 text-lg">
                Subscribe to our newsletter for the latest product updates, special offers, and insider tips.
              </p>
              
              <form className="flex flex-col sm:flex-row gap-3">
                <Input 
                  type="email" 
                  placeholder="Your email address" 
                  className="flex-grow px-5 py-3 rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-white"
                  required
                />
                <Button type="submit" className="bg-white text-primary hover:bg-white/90 whitespace-nowrap">
                  Subscribe Now
                </Button>
              </form>
              <p className="mt-4 text-sm opacity-80">
                By subscribing, you agree to our privacy policy and consent to receive updates.
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay: number;
  inView: boolean;
}

const FeatureCard = ({ icon, title, description, delay, inView }: FeatureCardProps) => {
  return (
    <motion.div
      className="bg-card rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow duration-300"
      initial={{ opacity: 0, y: 20 }}
      animate={inView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
      transition={{ duration: 0.5, delay }}
    >
      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-5">
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-muted-foreground">{description}</p>
    </motion.div>
  );
};

export default Home;
