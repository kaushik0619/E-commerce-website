import { 
  Product, InsertProduct, 
  Category, InsertCategory, 
  CartItem, InsertCartItem, 
  CartItemWithProduct,
  products, categories, cartItems
} from "@shared/schema";
import { db } from "./db";
import { eq, like, desc, and, asc } from "drizzle-orm";

// Storage interface
export interface IStorage {
  // Products
  getProducts(): Promise<Product[]>;
  getFeaturedProducts(limit?: number): Promise<Product[]>;
  getProductBySlug(slug: string): Promise<Product | undefined>;
  getProductById(id: number): Promise<Product | undefined>;
  getProductsByCategory(categorySlug: string): Promise<Product[]>;
  searchProducts(query: string): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Categories
  getCategories(): Promise<Category[]>;
  getCategoryBySlug(slug: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Cart
  getCartItems(sessionId: string): Promise<CartItemWithProduct[]>;
  getCartItem(sessionId: string, productId: number): Promise<CartItem | undefined>;
  addToCart(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(sessionId: string): Promise<void>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private products: Map<number, Product>;
  private categories: Map<number, Category>;
  private cartItems: Map<number, CartItem>;
  private productIdCounter: number;
  private categoryIdCounter: number;
  private cartItemIdCounter: number;

  constructor() {
    this.products = new Map();
    this.categories = new Map();
    this.cartItems = new Map();
    this.productIdCounter = 1;
    this.categoryIdCounter = 1;
    this.cartItemIdCounter = 1;

    // Initialize with sample data
    this.initializeCategories();
    this.initializeProducts();
  }

  // Products
  async getProducts(): Promise<Product[]> {
    return Array.from(this.products.values());
  }

  async getFeaturedProducts(limit: number = 6): Promise<Product[]> {
    return Array.from(this.products.values())
      .filter(product => product.featured)
      .slice(0, limit);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    return Array.from(this.products.values()).find(product => product.slug === slug);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    return this.products.get(id);
  }

  async getProductsByCategory(categorySlug: string): Promise<Product[]> {
    const category = Array.from(this.categories.values()).find(
      category => category.slug === categorySlug
    );
    if (!category) return [];
    
    return Array.from(this.products.values()).filter(
      product => product.categoryId === category.id
    );
  }

  async searchProducts(query: string): Promise<Product[]> {
    const lowercaseQuery = query.toLowerCase();
    return Array.from(this.products.values()).filter(product =>
      product.name.toLowerCase().includes(lowercaseQuery) ||
      product.description.toLowerCase().includes(lowercaseQuery)
    );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const id = this.productIdCounter++;
    const newProduct = { ...product, id } as Product;
    this.products.set(id, newProduct);
    return newProduct;
  }

  // Categories
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    return Array.from(this.categories.values()).find(
      category => category.slug === slug
    );
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const id = this.categoryIdCounter++;
    const newCategory = { ...category, id };
    this.categories.set(id, newCategory);
    return newCategory;
  }

  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const cartItems = Array.from(this.cartItems.values()).filter(
      item => item.sessionId === sessionId
    );
    
    return Promise.all(
      cartItems.map(async (item) => {
        const product = await this.getProductById(item.productId);
        return { ...item, product: product! } as CartItemWithProduct;
      })
    );
  }

  async getCartItem(sessionId: string, productId: number): Promise<CartItem | undefined> {
    return Array.from(this.cartItems.values()).find(
      item => item.sessionId === sessionId && item.productId === productId
    );
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    const existingItem = await this.getCartItem(cartItem.sessionId, cartItem.productId);
    
    if (existingItem) {
      return this.updateCartItemQuantity(
        existingItem.id, 
        existingItem.quantity + (cartItem.quantity || 1)
      );
    }
    
    const id = this.cartItemIdCounter++;
    const newCartItem = { 
      ...cartItem, 
      id, 
      createdAt: new Date() 
    } as CartItem;
    
    this.cartItems.set(id, newCartItem);
    return newCartItem;
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem> {
    const cartItem = this.cartItems.get(id);
    if (!cartItem) {
      throw new Error(`Cart item with id ${id} not found`);
    }
    
    const updatedItem = { ...cartItem, quantity };
    this.cartItems.set(id, updatedItem);
    return updatedItem;
  }

  async removeFromCart(id: number): Promise<void> {
    this.cartItems.delete(id);
  }

  async clearCart(sessionId: string): Promise<void> {
    const cartItemsToRemove = Array.from(this.cartItems.values())
      .filter(item => item.sessionId === sessionId)
      .map(item => item.id);
    
    cartItemsToRemove.forEach(id => this.cartItems.delete(id));
  }

  // Initialize sample data
  private initializeCategories() {
    const categories: InsertCategory[] = [
      { name: "Electronics", slug: "electronics" },
      { name: "Home", slug: "home" },
      { name: "Lifestyle", slug: "lifestyle" },
      { name: "Accessories", slug: "accessories" }
    ];
    
    categories.forEach(category => this.createCategory(category));
  }

  private initializeProducts() {
    const products: InsertProduct[] = [
      {
        name: "Wireless Headphones",
        slug: "wireless-headphones",
        description: "Premium sound quality with active noise cancellation",
        price: "249",
        imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
        categoryId: 1,
        featured: true,
        isNew: true,
        rating: "4.8"
      },
      {
        name: "Smart Watch",
        slug: "smart-watch",
        description: "Fitness tracking and notifications on your wrist",
        price: "199",
        imageUrl: "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08",
        categoryId: 1,
        featured: true,
        rating: "4.6"
      },
      {
        name: "Portable Speaker",
        slug: "portable-speaker",
        description: "Waterproof bluetooth speaker with 24h battery life",
        price: "79",
        originalPrice: "99",
        imageUrl: "https://images.unsplash.com/photo-1491933382434-500287f9b54b",
        categoryId: 1,
        featured: true,
        isSale: true,
        rating: "4.9"
      },
      {
        name: "Instant Camera",
        slug: "instant-camera",
        description: "Capture and print memories instantly",
        price: "89",
        imageUrl: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f",
        categoryId: 1,
        featured: true,
        rating: "4.4"
      },
      {
        name: "Smart Home Hub",
        slug: "smart-home-hub",
        description: "Control all your smart devices from one place",
        price: "129",
        imageUrl: "https://images.unsplash.com/photo-1600080199368-63ec00e9eb5f",
        categoryId: 2,
        featured: true,
        rating: "4.7"
      },
      {
        name: "Wireless Charger",
        slug: "wireless-charger",
        description: "Fast charging for all your compatible devices",
        price: "49",
        imageUrl: "https://images.unsplash.com/photo-1547949003-9792a18a2645",
        categoryId: 4,
        featured: true,
        isPopular: true,
        rating: "4.8"
      },
      {
        name: "Ultra HD Monitor",
        slug: "ultra-hd-monitor",
        description: "Crisp, clear display for work and entertainment",
        price: "399",
        imageUrl: "https://images.unsplash.com/photo-1527443224154-c4a3942d3acf",
        categoryId: 1,
        rating: "4.5"
      },
      {
        name: "Modern Desk Lamp",
        slug: "modern-desk-lamp",
        description: "Elegant design with adjustable brightness",
        price: "59",
        imageUrl: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c",
        categoryId: 2,
        rating: "4.2"
      },
      {
        name: "Ergonomic Chair",
        slug: "ergonomic-chair",
        description: "Maximum comfort for long working hours",
        price: "299",
        originalPrice: "349",
        imageUrl: "https://images.unsplash.com/photo-1580480055273-228ff5388ef8",
        categoryId: 2,
        isSale: true,
        rating: "4.7"
      },
      {
        name: "Fitness Tracker",
        slug: "fitness-tracker",
        description: "Monitor your health and activity metrics",
        price: "79",
        imageUrl: "https://images.unsplash.com/photo-1575311373937-040b8e1fd5b6",
        categoryId: 3,
        rating: "4.3"
      },
      {
        name: "Premium Yoga Mat",
        slug: "premium-yoga-mat",
        description: "Eco-friendly material with perfect grip",
        price: "45",
        imageUrl: "https://images.unsplash.com/photo-1518611012118-696072aa579a",
        categoryId: 3,
        rating: "4.4"
      },
      {
        name: "Minimalist Wallet",
        slug: "minimalist-wallet",
        description: "Slim design that fits all your essentials",
        price: "35",
        imageUrl: "https://images.unsplash.com/photo-1627123424574-724758594e93",
        categoryId: 4,
        isNew: true,
        rating: "4.6"
      }
    ];
    
    products.forEach(product => this.createProduct(product));
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // Products
  async getProducts(): Promise<Product[]> {
    return db.select().from(products).orderBy(asc(products.name));
  }

  async getFeaturedProducts(limit: number = 6): Promise<Product[]> {
    return db.select()
      .from(products)
      .where(eq(products.featured, true))
      .limit(limit);
  }

  async getProductBySlug(slug: string): Promise<Product | undefined> {
    const [product] = await db.select()
      .from(products)
      .where(eq(products.slug, slug));
    return product;
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db.select()
      .from(products)
      .where(eq(products.id, id));
    return product;
  }

  async getProductsByCategory(categorySlug: string): Promise<Product[]> {
    const [category] = await db.select()
      .from(categories)
      .where(eq(categories.slug, categorySlug));
    
    if (!category) return [];
    
    return db.select()
      .from(products)
      .where(eq(products.categoryId, category.id));
  }

  async searchProducts(query: string): Promise<Product[]> {
    return db.select()
      .from(products)
      .where(
        like(products.name, `%${query}%`)
      );
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products)
      .values(product)
      .returning();
    return newProduct;
  }
  
  // Categories
  async getCategories(): Promise<Category[]> {
    return db.select().from(categories).orderBy(asc(categories.name));
  }

  async getCategoryBySlug(slug: string): Promise<Category | undefined> {
    const [category] = await db.select()
      .from(categories)
      .where(eq(categories.slug, slug));
    return category;
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db.insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }
  
  // Cart
  async getCartItems(sessionId: string): Promise<CartItemWithProduct[]> {
    const items = await db.select()
      .from(cartItems)
      .where(eq(cartItems.sessionId, sessionId));
    
    return Promise.all(
      items.map(async (item) => {
        const [product] = await db.select()
          .from(products)
          .where(eq(products.id, item.productId));
        
        return { ...item, product } as CartItemWithProduct;
      })
    );
  }

  async getCartItem(sessionId: string, productId: number): Promise<CartItem | undefined> {
    const [item] = await db.select()
      .from(cartItems)
      .where(
        and(
          eq(cartItems.sessionId, sessionId),
          eq(cartItems.productId, productId)
        )
      );
    return item;
  }

  async addToCart(cartItem: InsertCartItem): Promise<CartItem> {
    const existingItem = await this.getCartItem(cartItem.sessionId, cartItem.productId);
    
    if (existingItem) {
      return this.updateCartItemQuantity(
        existingItem.id, 
        existingItem.quantity + (cartItem.quantity || 1)
      );
    }
    
    const [newItem] = await db.insert(cartItems)
      .values(cartItem)
      .returning();
    
    return newItem;
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem> {
    const [updatedItem] = await db.update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    
    if (!updatedItem) {
      throw new Error(`Cart item with id ${id} not found`);
    }
    
    return updatedItem;
  }

  async removeFromCart(id: number): Promise<void> {
    await db.delete(cartItems)
      .where(eq(cartItems.id, id));
  }

  async clearCart(sessionId: string): Promise<void> {
    await db.delete(cartItems)
      .where(eq(cartItems.sessionId, sessionId));
  }
  
  // Initialize database with sample data
  async initializeDatabase(): Promise<void> {
    const categoryResult = await db.select()
      .from(categories);
    
    if (categoryResult.length === 0) {
      // Add sample categories
      const sampleCategories: InsertCategory[] = [
        { name: "Electronics", slug: "electronics" },
        { name: "Home", slug: "home" },
        { name: "Lifestyle", slug: "lifestyle" },
        { name: "Accessories", slug: "accessories" }
      ];
      
      for (const category of sampleCategories) {
        await this.createCategory(category);
      }
      
      // Add sample products
      const sampleProducts: InsertProduct[] = [
        {
          name: "Wireless Headphones",
          slug: "wireless-headphones",
          description: "Premium sound quality with active noise cancellation",
          price: "249",
          imageUrl: "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
          categoryId: 1,
          featured: true,
          isNew: true,
          rating: "4.8"
        },
        {
          name: "Smart Watch",
          slug: "smart-watch",
          description: "Fitness tracking and notifications on your wrist",
          price: "199",
          imageUrl: "https://images.unsplash.com/photo-1600080972464-8e5f35f63d08",
          categoryId: 1,
          featured: true,
          rating: "4.6"
        },
        {
          name: "Portable Speaker",
          slug: "portable-speaker",
          description: "Waterproof bluetooth speaker with 24h battery life",
          price: "79",
          originalPrice: "99",
          imageUrl: "https://images.unsplash.com/photo-1491933382434-500287f9b54b",
          categoryId: 1,
          featured: true,
          isSale: true,
          rating: "4.9"
        },
        {
          name: "Instant Camera",
          slug: "instant-camera",
          description: "Capture and print memories instantly",
          price: "89",
          imageUrl: "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f",
          categoryId: 1,
          featured: true,
          rating: "4.4"
        },
        {
          name: "Smart Home Hub",
          slug: "smart-home-hub",
          description: "Control all your smart devices from one place",
          price: "129",
          imageUrl: "https://images.unsplash.com/photo-1600080199368-63ec00e9eb5f",
          categoryId: 2,
          featured: true,
          rating: "4.7"
        },
        {
          name: "Wireless Charger",
          slug: "wireless-charger",
          description: "Fast charging for all your compatible devices",
          price: "49",
          imageUrl: "https://images.unsplash.com/photo-1547949003-9792a18a2645",
          categoryId: 4,
          featured: true,
          isPopular: true,
          rating: "4.8"
        }
      ];
      
      for (const product of sampleProducts) {
        await this.createProduct(product);
      }
    }
  }
}

// Export an instance of DatabaseStorage
export const storage = new DatabaseStorage();
